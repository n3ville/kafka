using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.Text;
using System.Text.RegularExpressions;

namespace Infinitum.SQL.Kafka
{
    /// <summary>
    /// Минимальный клиент HashiCorp Vault для SQL CLR-сборок.
    ///
    /// ВАРИАНТ 2 (промежуточное решение): VaultUrl / Token / MountPoint / Path
    /// передаются вызывающей стороной как параметры при каждом вызове хранимой
    /// процедуры — сама сборка их нигде не хранит и не читает с диска/окружения.
    ///
    /// ВАЖНО (осознанный компромисс, не забыть при пересмотре):
    /// Token проходит через слой T-SQL параметров, а значит потенциально попадает
    /// в plan cache / Query Store / Extended Events / Profiler трассировки /
    /// error-логи SQL Server. Для регулярной прод-нагрузки это временное решение —
    /// см. обсуждение вариантов с Vault Agent / cert-auth для финальной версии.
    ///
    /// JSON парсится вручную (без Newtonsoft.Json/System.Web.Extensions), чтобы не
    /// плодить лишние CREATE ASSEMBLY-зависимости в SQL Server.
    /// </summary>
    internal static class VaultClient
    {
        // TTL кэша секретов в памяти CLR AppDomain, чтобы не дёргать Vault на
        // каждый вызов ProduceMessage/RunConsume. Кэш ключуется по url+mount+path,
        // НЕ по токену — то есть если один и тот же путь запрашивают с разными
        // токенами подряд, в течение TTL вернётся результат первого успешного запроса.
        // Если это нежелательно (например, разные вызовы должны видеть live-данные
        // при смене токена) — уменьшите CacheTtl или добавьте токен в ключ кэша.
        private static readonly TimeSpan CacheTtl = TimeSpan.FromMinutes(10);

        private static readonly Dictionary<string, CachedSecret> Cache = new Dictionary<string, CachedSecret>();
        private static readonly object CacheLock = new object();

        private class CachedSecret
        {
            public Dictionary<string, string> Data;
            public DateTime ExpiresAtUtc;
        }

        /// <summary>
        /// Читает секрет из KV v2. mount — имя движка (например "test" или "secret"),
        /// path — путь секрета внутри движка (например "scout/kafka").
        /// Итоговый URL: {vaultUrl}/v1/{mount}/data/{path}
        /// </summary>
        public static Dictionary<string, string> ReadSecret(string vaultUrl, string token, string mount, string path)
        {
            if (string.IsNullOrWhiteSpace(vaultUrl))
                throw new ArgumentException("VaultUrl is required.", nameof(vaultUrl));
            if (string.IsNullOrWhiteSpace(token))
                throw new ArgumentException("Vault token is required.", nameof(token));
            if (string.IsNullOrWhiteSpace(mount))
                throw new ArgumentException("Vault mount point is required.", nameof(mount));
            if (string.IsNullOrWhiteSpace(path))
                throw new ArgumentException("Vault secret path is required.", nameof(path));

            var normalizedUrl = vaultUrl.TrimEnd('/');
            var cacheKey = $"{normalizedUrl}|{mount}|{path}";

            lock (CacheLock)
            {
                if (Cache.TryGetValue(cacheKey, out var cached) && cached.ExpiresAtUtc > DateTime.UtcNow)
                    return cached.Data;
            }

            var data = FetchSecretFromVault(normalizedUrl, token, mount, path);

            lock (CacheLock)
            {
                Cache[cacheKey] = new CachedSecret
                {
                    Data = data,
                    ExpiresAtUtc = DateTime.UtcNow.Add(CacheTtl)
                };
            }

            return data;
        }

        /// <summary>Принудительно сбросить кэш (например, если знаете, что секрет в Vault поменялся).</summary>
        public static void InvalidateCache()
        {
            lock (CacheLock)
            {
                Cache.Clear();
            }
        }

        private static Dictionary<string, string> FetchSecretFromVault(string vaultUrl, string token, string mount, string path)
        {
            // Важно на SQL CLR: без явного указания протокола некоторые хосты
            // по умолчанию используют SSL3/TLS1.0, а Vault обычно требует TLS1.2+.
            ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;

            var url = $"{vaultUrl}/v1/{mount}/data/{path}";

            var request = (HttpWebRequest)WebRequest.Create(url);
            request.Method = "GET";
            request.Headers["X-Vault-Token"] = token;
            request.Accept = "application/json";
            request.Timeout = 5000;
            request.ReadWriteTimeout = 5000;
            request.Proxy = null;

            try
            {
                using (var response = (HttpWebResponse)request.GetResponse())
                using (var stream = response.GetResponseStream())
                using (var reader = new StreamReader(stream, Encoding.UTF8))
                {
                    var body = reader.ReadToEnd();
                    return ParseKvV2Data(body);
                }
            }
            catch (WebException wex)
            {
                string details = "";
                if (wex.Response != null)
                {
                    using (var stream = wex.Response.GetResponseStream())
                    using (var reader = new StreamReader(stream ?? Stream.Null, Encoding.UTF8))
                    {
                        details = reader.ReadToEnd();
                    }
                }
                throw new Exception($"Vault request failed for {mount}/{path}: {wex.Message}. {details}", wex);
            }
        }

        /// <summary>
        /// Минимальный парсер JSON-ответа Vault KV v2 вида:
        /// { "data": { "data": { "username": "...", "password": "..." }, "metadata": {...} } }
        /// Извлекает плоский объект data.data (строка-строка).
        /// </summary>
        internal static Dictionary<string, string> ParseKvV2Data(string json)
        {
            var result = new Dictionary<string, string>();

            var outerDataIdx = json.IndexOf("\"data\"", StringComparison.Ordinal);
            if (outerDataIdx < 0)
                throw new Exception("Unexpected Vault response: no top-level 'data' field.");

            var innerDataIdx = json.IndexOf("\"data\"", outerDataIdx + 6, StringComparison.Ordinal);
            if (innerDataIdx < 0)
                throw new Exception("Unexpected Vault response: no nested 'data.data' field (secret may not exist).");

            var braceStart = json.IndexOf('{', innerDataIdx);
            if (braceStart < 0)
                throw new Exception("Unexpected Vault response: malformed 'data.data' object.");

            int depth = 0;
            int braceEnd = -1;
            for (int i = braceStart; i < json.Length; i++)
            {
                if (json[i] == '{') depth++;
                else if (json[i] == '}')
                {
                    depth--;
                    if (depth == 0) { braceEnd = i; break; }
                }
            }
            if (braceEnd < 0)
                throw new Exception("Unexpected Vault response: unbalanced braces in 'data.data'.");

            var innerJson = json.Substring(braceStart + 1, braceEnd - braceStart - 1);

            var pairRegex = new Regex("\"(?<key>[^\"]+)\"\\s*:\\s*\"(?<val>(?:[^\"\\\\]|\\\\.)*)\"");
            foreach (Match m in pairRegex.Matches(innerJson))
            {
                var key = m.Groups["key"].Value;
                var val = Regex.Unescape(m.Groups["val"].Value);
                result[key] = val;
            }

            if (result.Count == 0)
                throw new Exception("Vault secret data.data parsed as empty — check the mount/path/content.");

            return result;
        }
    }
}
